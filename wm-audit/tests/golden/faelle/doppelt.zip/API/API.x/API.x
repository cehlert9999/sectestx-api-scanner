{
 "apiName": "X",
 "apiVersion": "1.0",
 "type": "REST",
 "nativeEndpoint": [
  {
   "uri": "https://backend.example",
   "passSecurityHeaders": false
  }
 ]
}
